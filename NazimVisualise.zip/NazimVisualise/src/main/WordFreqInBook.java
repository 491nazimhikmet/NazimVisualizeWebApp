package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Book;
import model.Word;
import dao.BookDao;
import dao.WordDao;
import processing.core.PApplet;

public class WordFreqInBook extends PApplet{
//aranan sözcük hangi kitapta ne kadar geçiyor?
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.WordFreqInBook"});
	}
	//stem is the word that user has typed the searchbar
	String stem="istanbul";
	List<Book> booksWithCount;
	
	public void countInBooks(String stem){
		WordDao wordDao = new WordDao();	
		try {
			booksWithCount = wordDao.getBookCounterOfWord(stem);
			System.out.println(booksWithCount.size());
			for(int i=0;i<booksWithCount.size();i++){
					System.out.println(booksWithCount.get(i).getName()+" : "+booksWithCount.get(i).getWordCnt());
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void setup () {
		
		size (displayWidth, displayHeight);	
		noStroke();
		frameRate(50); 
		countInBooks(stem); 
	}
	
	public void draw(){
		background(0);
		int n = booksWithCount.size();
		int inter_n = (displayWidth-120)/(n+1);	//
		int locOfXAxis = height-60;
		
		strokeWeight(2);
		line(60,locOfXAxis,displayWidth-60,locOfXAxis);
		int height;
		text(stem,100,100);
		
		for(int i=0;i<n;i++){
			//ellipse(60+((i+1)*inter_n),locOfXAxis,1,1);
			height = locOfXAxis - 5*booksWithCount.get(i).getWordCnt();
			if(height<0) height=20;
			//System.out.println("count "+booksWithCount.get(i).getWordCnt());
			strokeWeight(2);
			stroke(200,200,50);
			line(60+((i+1)*inter_n),height,60+((i+1)*inter_n),locOfXAxis);
			textSize(16);
			text(booksWithCount.get(i).getWordCnt(),60+((i+1)*inter_n),height-6);
			
			if(mouseX>50+(i+1)*inter_n&&mouseX<70+(i+1)*inter_n&&mouseY>height){
				textSize(12);
				text(booksWithCount.get(i).getName(),mouseX-50,locOfXAxis+20);
			}
		}
	}		
}
