package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;

//tekrar etmeyen sözcükleri çemberden çıkaralım
// fazla tekrar varsa tickness artsın

public class RepeatedWords extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.RepeatedWords"});
	}
	
	
	//max height : 1080, max width: 1920;
	
	int height = 800 ;
	int width = 1200;
	
	int id=6183;//seçilen şiirin IDsi
	List<Word> words;//şözcükleriirdeki söz
	
	public void setup () {
		
		size (width, height);		
		frameRate(50);  	
		
		WordDao wordDao = new WordDao();
		
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		stroke(0);
		int r= (int) map(height,0,1080,0,300);
		float shift = (int) map(width,0,1920,0,50);
		float centerX = width/2 - 7*shift;
		float centerY  = height/2-shift;
		float interval = 2*PI/words.size();
		float textX=centerX-r;
		float textY=map(height,0,1080,0,200);
		
		ellipseMode(CENTER);
		ellipse(centerX,centerY,2*r,2*r);
		
		float x=0;
		float y=0;
		float xR=0;
		float yR=0;
		
		int preline=words.get(0).getWorkLineID();
	
		textSize((int)map(height,0,1080,0,16));
		
		for(int i=0;i<words.size();i++){	
			x=centerX-r*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY-r*sin(i*interval);
			
			shift = map(width,0,1920,0,(float) (2.5*(float)words.get(i).getWordStart()));
			textX = (float) (1.8*centerX+shift); 
			
			if(words.get(i).getWorkLineID()!=preline){
				textY+=map(height,0,1080,0,15);
			}	
			
			preline=words.get(i).getWorkLineID();
			fill(0);
			
			text(words.get(i).toString(),textX,textY);
			noFill();
			
			for(int j=0;j<words.size();j++){//şiirdeki kendisi dışında her bir kelime için parsed formu control et
				
				if(words.get(i).getDisambiguated().equals(words.get(j).getDisambiguated())&&j!=i){
					
					xR=centerX-r*cos(j*interval);
					yR=centerY-r*sin(j*interval);
					
					fill(0);
					//ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
					ellipse(xR,yR,map(height,0,1080,0,10),map(height,0,1080,0,10));
					noFill();
					
					strokeWeight((float) 0.5);
					curve(x+xR,y+yR,x,y,xR,yR,x-xR,y-yR);
					
					stroke(0);
				}	
			}
			if(mouseX<x+5 && mouseX>x-5 && mouseY<y+5 && mouseY>y-5 || mouseX<xR+5 && mouseX>xR-5 && mouseY<yR+5 && mouseY>yR-5){
				stroke(250,0,0);
				fill(250,0,0);
				text(words.get(i).toString(),textX,textY);
				ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
				ellipse(xR,yR,map(height,0,1080,0,10),map(height,0,1080,0,10));
				noFill();
			}
		}
		

		
	
	}
}
		

