package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class Adjectives extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Adjectives"});
	}
	
	int id=6525;//seçilen şiirin IDsi
	List<Word> words;//şiirdeki sözcükler
	List<WorkLine> worklines;//satırlar
	List<Word> adjectives = new ArrayList<Word>();//kontrol etmek için tuttum, olmasa da olur
	
	public void setup () {
		int width = 1080;
		int height = 600;
		size (width, height);		
		frameRate(50);  	
		
		WordDao wordDao = new WordDao();
		WorkLineDao workLineDao = new WorkLineDao();
			
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			worklines = workLineDao.getWorkLineOfAWork(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		stroke(0);
		fill(0);
		
		int x=(int) map(width,0,1920,0,100);
		int y=(int) map(height,0,1080,0,30);
		int margin = (int) map(height,0,1080,0,60);
		int visualHeight = height - margin;
		int intervalY= visualHeight/(worklines.size()-1);
		int intervalX=(int) map(width,0,1920,0,40);
		int r=(int) map(height,0,1080,0,2);
		int textY=(int) map(height,0,1080,0,80);
		int textX=(int) map(width,0,1920,0,430);
		int textY2=(int) map(height,0,1080,0,80);
		int textX2=(int) map(width,0,1920,0,680);
		textSize((int) map(width,0,1920,0,15));
		text("Seçili Şiir: "+worklines.get(0).getLine(),(int) map(width,0,1920,0,360),textY-(int) map(height,0,1080,0,30));
		text("Şiirde Geçen Sıfatlar:",(int) map(width,0,1920,0,400),textY);
		text("Diğer Sözcükler:",(int) map(width,0,1920,0,650),textY);
		textSize((int) map(width,0,1920,0,12));
		for(int i=0;i<words.size();i++){
			System.out.print(words.get(i).getText()+"	"+words.get(i).getParsedForm()+"	");
			System.out.println();
			if(mouseX<x+4*r && mouseX>x-(4*r) && mouseY<y+(4*r)&&mouseY>y-(4*r)){
				fill(250,0,0);
			}	
			if(isAdj(i)){	
				if(textY>height-margin/2){
					textY = (int) map(height,0,1080,0,100);
					textX += (int) map(width,0,1920,0,100);
				}
				textY += (int) map(height,0,1080,0,20);
				quad(x-(4*r), y,x, y-(4*r), x+(4*r), y,x,y+(4*r));
				text(words.get(i).getText(),textX,textY);		
			}
			else{ 
				if(textY2>height-margin/2){
					textY2 = (int) map(height,0,1080,0,100);
					textX2 += (int) map(width,0,1920,0,100);
				}
				ellipse(x,y,r,r);
				if(words.get(i).getWorkLineID()!=worklines.get(0).getLineID()){
					textY2 += (int) map(height,0,1080,0,20);
					text(words.get(i).getText(),textX2,textY2);
				}
			}
		
			fill(0);
			x+=intervalX;
			if(i+1!=words.size() && words.get(i+1).getWorkLineID()!=words.get(i).getWorkLineID()){
				y+=intervalY;
				x=(int) map(width,0,1920,0,100);
			}
			//text(words.get(i).getText(),100,(i+1)*10);	
		}		
	}
	public boolean isAdj(int i){
		if (words.get(i).getParsedForm().contains("Adj")){ 
			adjectives.add(words.get(i));
			return true;
		}
		else return false;	
	}	
}
		

