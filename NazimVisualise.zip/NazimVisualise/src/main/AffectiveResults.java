package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class AffectiveResults extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.AffectiveResults"});
	}
	//id of a poem
	int id=6161;
	
	List<AffectiveResult> affectiveResults; 
	
	int height = 600 ;
	int width = 1200;

	public void setup () {
		size (width, height);		

		frameRate(50);  	
		
		AffectiveDao affectiveDao = new AffectiveDao();
		
		try {		
			affectiveResults = affectiveDao.getResultsByWorkId(id);
			
			for(int i=0;i<affectiveResults.size();i++){
				System.out.println(affectiveResults.get(i).getText()+"val:  "+affectiveResults.get(i).getValence()+"ar: "+affectiveResults.get(i).getArousal()+"domin: "+affectiveResults.get(i).getDominance());
			}		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		
		int topMargin = height/12;
		int leftMargin=width/3;
		int rightMargin=width*7/8;
		
		int visualHeight=height-topMargin;
		int visualWidth=rightMargin-leftMargin;
		int y = displayHeight/12;
		
		stroke(0);
		fill(0);
		
		textSize((int) map(height,0,1080,0,24));
		text("-",leftMargin,y-y/4);
		text("+",rightMargin,y-y/4);
		
		
		line(leftMargin,y,leftMargin,y+height);
		line(rightMargin,y,rightMargin,y+height);
	
		int intervalY = height/affectiveResults.size()-1;
		
		float valenceX=leftMargin;
		float arousalX=leftMargin;
		float dominanceX=leftMargin;
		
		int r= (int) map(height,0,1080,0,10);
		
		float previousX_val = leftMargin+ Float.parseFloat(affectiveResults.get(0).getValence())/5 * visualWidth;
		float previousX_ar = leftMargin+ Float.parseFloat(affectiveResults.get(0).getArousal())/5 * visualWidth;
		float previousX_dom = leftMargin+ Float.parseFloat(affectiveResults.get(0).getDominance())/5 * visualWidth;

		int previousY = y;
		
		for(int i=0;i<affectiveResults.size();i++){
			valenceX += Float.parseFloat(affectiveResults.get(i).getValence())/5 * visualWidth;
			arousalX += Float.parseFloat(affectiveResults.get(i).getArousal())/5 * visualWidth;
			dominanceX += Float.parseFloat(affectiveResults.get(i).getDominance())/5 * visualWidth;
			
			stroke(250,0,0);
			fill(250,0,0);
			ellipseMode(CENTER);
		
			ellipse(valenceX,y,r,r);
			//text(affectiveResults.get(i).getValence(),rightMargin+10,y);
			line(previousX_val,previousY,valenceX,y);
			fill(0,0,250);
			stroke(0,0,250);
			ellipse(arousalX,y,r,r);
			line(previousX_ar,previousY,arousalX,y);
			fill(220,0,220);
			stroke(220,0,220);
			ellipse(dominanceX,y,r,r);
			line(previousX_dom,previousY,dominanceX,y);
			
			previousX_val=valenceX;
			previousX_ar=arousalX;
			previousX_dom=dominanceX;
			previousY=y;
			y+=intervalY;
			valenceX=leftMargin;
			arousalX=leftMargin;
			dominanceX=leftMargin;
		}	
	}		
	
}
		

