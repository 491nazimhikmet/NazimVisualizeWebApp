package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class Rounded extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Rounded"});
	}
	
	int id=6184;//seçilen şiirin IDsi
	List<Word> words;
	List<WorkLine> worklines;
	List<AffectiveResult> affectiveResults;
	
	float[] red; 
	float[] green; 
	float[] blue;
	
	
	public void setup () {
		int width = 1080;
		int height = 600;
		size (width, height);			
		frameRate(50);  	
		
		WordDao wordDao = new WordDao();
		WorkLineDao workLineDao = new WorkLineDao();
		AffectiveDao affectiveDao = new AffectiveDao();
			
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			worklines = workLineDao.getWorkLineOfAWork(id);
			affectiveResults = affectiveDao.getResultsByWorkId(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		/*for(int i=0;i<worklines.size();i++){
			System.out.println(worklines.get(i));
		}*/
		
		red = new float[worklines.size()];
		green = new float[worklines.size()];
		blue = new float[worklines.size()];
		
		for(int i=0;i<worklines.size();i++){
			red[i] = random(255);
			green[i] = random(255);
			blue[i] = random(255);
		}
		
	}
	
	public void draw(){
		background(255);
		
		int rIn = (int) map(height,0,1080,0,500);
		int rOut = (int) map(height,0,1080,0,800);

		int centerX = width/2;
		int centerY  = height*3/4;
		float intervalOut = PI/words.size();
		float intervalIn = PI/worklines.size();
		
		int shift = (int) map(height,0,1080,0,250);
		int textY = (int) map(height,0,1080,0,800);
		int textX = (int) map(width,0,1920,0,880);
		
		fill(0);
		stroke(0);
		/*
		text("olumluluk/valence",textX-shift,textY);
		text("uyarılma/arousal",textX,textY);
		text("baskınlık/dominance",textX+shift,textY);

		line(centerX-shift,centerY,centerX-shift,centerY+shift);
		line(centerX,centerY,centerX,centerY+shift);
		line(centerX+shift,centerY,centerX+shift,centerY+shift);
		
		for(int i=0 ; i<6 ; i++){
			ellipse(centerX-shift,centerY+(shift/5)*i,4,4);
			ellipse(centerX,centerY+(shift/5)*i,4,4);
			ellipse(centerX+shift,centerY+(shift/5)*i,4,4);
		}*/
		
		ellipseMode(CENTER);
	
		
		float xOut=0;
		float yOut=0;
		float xIn=0;
		float yIn=0;
		
		int ellipseSize = 10;
		int mouseMargin = 5;
		
		float valence =3;
		float arousal =3;
		float dominance =3;
		
		
		for(int i=0;i<worklines.size();i++){
			
			stroke(red[i],green[i],blue[i]);
			fill(red[i],green[i],blue[i]);
			

			xIn=centerX-rIn*cos(i*intervalIn);
			yIn=centerY-(rIn*sin(i*intervalIn));
			ellipseSize = 10;
			ellipse(xIn,yIn,ellipseSize,ellipseSize);		
			
			ellipseSize=8;
			
			for(int j=0;j<words.size();j++){	
				xOut=centerX-rOut*cos(j*intervalOut);
				yOut=centerY-rOut*sin(j*intervalOut);
				
				stroke(red[i],green[i],blue[i]);
				fill(red[i],green[i],blue[i]);
				
				
				if(worklines.get(i).getLineID()==words.get(j).getWorkLineID()){
					ellipse(xOut,yOut,ellipseSize,ellipseSize);	
					line(xOut,yOut,xIn,yIn);
				}		
			}
			/*
			if(i<affectiveResults.size()){
				valence   = Float.parseFloat(affectiveResults.get(i).getValence());
				arousal   = Float.parseFloat(affectiveResults.get(i).getArousal());
				dominance = Float.parseFloat(affectiveResults.get(i).getDominance());
			}*/
			
		}		
	}
}
		

