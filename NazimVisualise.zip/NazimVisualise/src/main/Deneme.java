package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;

//tekrar etmeyen sözcükleri çemberden çıkaralım
// fazla tekrar varsa tickness artsın

public class Deneme extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Deneme"});
	}
	
	
	//max height : 1080, max width: 1920;
	
	int height = 800 ;
	int width = 1200;
	
	int id=6502;//seçilen şiirin IDsi
	List<Word> words;
	Work work;
	
	public void setup () {
		
		size (width, height);		
		frameRate(50);  	
		
		WordDao wordDao = new WordDao();
		WorkDao workDao = new WorkDao();

		
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			work = workDao.getWorkByID(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		stroke(0);
		
		int r= (int) map(height,0,1080,0,200);
		float shift = (int) map(width,0,1920,0,100);
		
		float interval = 2*PI/words.size();
		
		float centerX1 = width/4-shift;
		float centerY1  = height/4+shift/2;
		
		float centerX2 = width/4-shift;
		float centerY2 = height*3/4;
		
		float centerX3 = width*3/4+shift;
		float centerY3  = height/4+shift/2;
		

		float centerX4 = width*3/4+shift;
		float centerY4 = height*3/4;
		
		float centerX5 = width/2;
		float centerY5 = height/2;
		
		textSize(15);
		text("Sözcüklerin zaman çekimlerine göre ",width/2-5*shift/2,shift);
		text("'"+work.getName()+"'",width/2-2*shift,shift*3/2);

		
		ellipseMode(CENTER);
		textSize(13);
		
		ellipse(centerX1,centerY1,2*r,2*r);
		ellipse(centerX2,centerY2,2*r,2*r);
		ellipse(centerX3,centerY3,2*r,2*r);
		ellipse(centerX4,centerY4,2*r,2*r);
		ellipse(centerX5,centerY5,5*r/2,5*r/2);
		
		int r_in=5;
		
		float x=0;
		float y=0;
		
		//geçmiş zaman
		text("geçmiş zaman",centerX1-shift,centerY1-r-shift/2);
		
		for(int i=0;i<words.size();i++){	
			
			x=centerX1-r*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY1-r*sin(i*interval);
				
			fill(0);
			System.out.println("a");
			ellipse(x,y,map(height,0,1080,0,5),map(height,0,1080,0,5));
			//ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));

			//r_in++;
			stroke(0,0,255);
			//System.out.println(words.get(i).getParsedForm().contains("Fut"));
			if(words.get(i).getParsedForm().contains("Past")){	
				line(x,y,centerX1,centerY1);
			}
			noFill();
			noStroke();
		}
		//System.out.println("b");
		//şimdiki zaman
		text("şimdiki zaman",centerX2-shift,centerY2-r-shift/2);

		for(int i=0;i<words.size();i++){	
			
			x=centerX2-r*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY2-r*sin(i*interval);
			
			fill(0);	
			ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
			
			stroke(0,255,0);
			
			if(words.get(i).getParsedForm().contains("Prog")){
				line(x,y,centerX2,centerY2);
			}
			noFill();
			noStroke();
		}
		
		//geniş zaman
		text("geniş zaman",centerX3-shift,centerY3-r-shift/2);

		for(int i=0;i<words.size();i++){	
			
			x=centerX3-r*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY3-r*sin(i*interval);
			
			fill(0);		
			ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
			
			stroke(255,0,0);	
			if(words.get(i).getParsedForm().contains("Aor")){	
				line(x,y,centerX3,centerY3);
			}
			noFill();
			noStroke();
		}
		
		//gelecek zaman
		text("gelecek zaman",centerX4-shift,centerY4-r-shift/2);
		for(int i=0;i<words.size();i++){	
			
			x=centerX4-r*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY4-r*sin(i*interval);
			
			fill(0);	
			ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
			
			stroke(255,255,0);
			if(words.get(i).getParsedForm().contains("Fut")){	
				line(x,y,centerX4,centerY4);  
			}
			noFill();
			noStroke();
		}
		for(int i=0;i<words.size();i++){	
			
			x=centerX5-5*r/4*cos(i*interval); //herbir kelime için x ve y hesapla -> circle çiz
			y=centerY5-5*r/4*sin(i*interval);
			
			fill(0);	
			ellipse(x,y,map(height,0,1080,0,10),map(height,0,1080,0,10));
			
			if(words.get(i).getParsedForm().contains("Fut")){	
				stroke(255,255,0);
				line(x,y,centerX5,centerY5);
				noStroke();
			}
			if(words.get(i).getParsedForm().contains("Past")){	
				stroke(0,0,255);
				line(x,y,centerX5,centerY5);
				noStroke();
			}
			if(words.get(i).getParsedForm().contains("Aor")){	
				stroke(255,0,0);	
				line(x,y,centerX5,centerY5);
				noStroke();
			}
			if(words.get(i).getParsedForm().contains("Prog")){	
				stroke(0,255,0);
				line(x,y,centerX5,centerY5);
				noStroke();
			}
			noFill();

		}
	}
}
		

