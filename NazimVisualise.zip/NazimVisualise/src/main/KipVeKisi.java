package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class KipVeKisi extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.KipVeKisi"});
	}
	
	int id=6234;//seçilen şiirin IDsi
	List<Word> words;//şözcükler
	List<WorkLine> worklines; //satırlar
	
	public void setup () {
		int width = 1000;
		int height = 600;
		size (width, height);	
		frameRate(50);  	
		
		WordDao wordDao = new WordDao();
		WorkLineDao workLineDao = new WorkLineDao();
			
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			worklines = workLineDao.getWorkLineOfAWork(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		stroke(0);
		fill(0);
		int x=0;
		int y=0;
		int margin = (int) map(height,0,1080,0,60);
		int visualHeight=displayHeight-margin;
		int intervalY= visualHeight/(worklines.size()-1);
		//if(worklines.size()>50)
			//intervalY =2*intervalY; // çok uzun şiirlerde karışıklık oluyor diye böyle yaptım, değiştirmek lazım!
		int intervalX=(int) map(width,0,1920,0,40);
		int r = (int) map(height,0,1080,0,10);
		int textX = (int) map(width,0,1920,0,60);
		int textY = (int) map(height,0,1080,0,100);
	
		text("KİP VE KİŞİ ÇEKİMLERİNE GÖRE",textX,textY);
		textX += (int) map(width,0,1920,0,10);
		textY += (int) map(height,0,1080,0,30);
		text(worklines.get(0).toString()+":",textX,textY);

		textX = (int) map(width,0,1920,0,100);
		textY= (int) map(height,0,1080,0,250);
		
		int shiftX = (int) map(width,0,1920,0,160);
		int shiftY = (int) map(height,0,1080,0,30);
		
		strokeWeight(3);stroke(255,0,0);fill(255,0,0);line(textX+shiftX/2,textY,textX+shiftX,textY);text("BEN",textX,textY);
		strokeWeight(3);stroke(255,220,0);fill(255,220,0);line(textX+shiftX/2,textY+shiftY,textX+shiftX,textY+shiftY);text("SEN",textX,textY+shiftY);
		strokeWeight(3);stroke(0,240,0);fill(0,240,0);line(textX+shiftX/2,textY+shiftY*2,textX+shiftX,textY+shiftY*2);text("O",textX,textY+shiftY*2);
		strokeWeight(3);stroke(0,240,255);fill(0,240,255);line(textX+shiftX/2,textY+shiftY*3,textX+shiftX,textY+shiftY*3);text("BİZ",textX,textY+shiftY*3);
		strokeWeight(3);stroke(0,0,255);fill(0,0,255);line(textX+shiftX/2,textY+shiftY*4,textX+shiftX,textY+shiftY*4);text("SİZ",textX,textY+shiftY*4);
		strokeWeight(3);stroke(255,0,255);fill(255,0,255);line(textX+shiftX/2,textY+shiftY*5,textX+shiftX,textY+shiftY*5);text("ONLAR",textX,textY+shiftY*5);

		textY=(int) map(width,0,1920,0,500);
		stroke(0);fill(0);
		text("GEÇMİŞ ZAMAN",textX,textY);
		strokeWeight(2);
		shiftX = (int) map(width,0,1920,0,200);
		x=textX+shiftX;
		y=textY;
		line(x-r,y,x,y-r);
		line(x-r,y,x+r,y);
		line(x-r,y,x,y+r);
		shiftY = (int) map(height,0,1080,0,5);
		textY += (int) map(height,0,1080,0,50);
		y=textY-shiftY;
		text("ŞİMDİKİ ZAMAN",textX,textY);
		rectMode(CENTER);
		rect(x,y,r,r);
		textY += (int) map(height,0,1080,0,50);
		y=textY;
		text("GELECEK ZAMAN",textX,textY);
		strokeWeight(2);
		line(x+r,y,x,y-r);
		line(x-r,y,x+r,y);
		line(x+r,y,x,y+r);
		textY += (int) map(height,0,1080,0,50);
		y=textY;
		text("GENİŞ ZAMAN",textX,textY);
		ellipseMode(CENTER);
		ellipse(x,y,3*r/2,3*r/2);
		
		
		
		x = (int) map(width,0,1920,0,600);
		y = (int) map(height,0,1080,0,30);
		r = (int) map(height,0,1080,0,9);
		textX = (int) map(width,0,1920,0,1300);
		textY = (int) map(height,0,1080,0,500);
		
		int flag=0;
		for(int i=0;i<words.size();i++){
			if(words.get(i).getWorkLineID() != worklines.get(0).getLineID()||words.get(i).getWorkLineID()!=worklines.get(worklines.size()-1).getLineID()){
				System.out.println(words.get(i).getWorkLineID()+" "+worklines.get(0).getLineID()); //idler match etmiyor words with parsedform
				//System.out.print(words.get(i).getText()+"	"+words.get(i).getParsedForm()+"	");
				
				if(y>height-margin/2){
					y = (int) map(height,0,1080,0,30);
					x = (int) map(width,0,1920,0,1000);
					flag=1;
				}
				myStroke(i);
				if(words.get(i).getParsedForm().contains("Past")){ //geçmiş zaman
						strokeWeight(2);
						line(x-r,y,x,y-r);
						line(x-r,y,x+r,y);
						line(x-r,y,x,y+r);
				}else if(words.get(i).getParsedForm().contains("Prog")){ //şimdiki zaman
					rectMode(CENTER);
					rect(x,y,r,r);
				}else if(words.get(i).getParsedForm().contains("Fut")){ //gelecek zaman
					strokeWeight(2);
					line(x+r,y,x,y-r);
					line(x-r,y,x+r,y);
					line(x+r,y,x,y+r);
				}else if(words.get(i).getParsedForm().contains("Aor")){ //geniş zaman
					ellipseMode(CENTER);
					ellipse(x,y,3*r/2,3*r/2);
				}else
					ellipse(x,y,r/3,r/3);
				
				if(mouseX<x+r && mouseX>x-r && mouseY<y+r&&mouseY>y-r){
					textSize(13);
					text(words.get(i).getText(),textX,textY);
					//text(words.get(i).getParsedForm(),textX,textY+(int) map(height,0,1080,0,40));
				}	
				
				x+=intervalX;
				if(i+1!=words.size() && words.get(i+1).getWorkLineID()!=words.get(i).getWorkLineID()){
					y += intervalY;
					if(flag==1){x = (int) map(width,0,1920,0,1000);}
					else x = (int) map(width,0,1920,0,600);
					System.out.println();
				}
				//text(words.get(i).getText(),100,(i+1)*10);
			}
		}
	}
	
	
	
	
	public void myStroke(int i){
		if (words.get(i).getParsedForm().contains("A1sg")||words.get(i).getParsedForm().contains("P1sg")){// ben-kırmızı
			fill(255,0,0);
			stroke(255,0,0);			
		}else if (words.get(i).getParsedForm().contains("A2sg")||words.get(i).getParsedForm().contains("P2sg")){// sen-sarı
			fill(255,220,0);
			stroke(255,220,0);
		}else if (words.get(i).getParsedForm().contains("A1pl")||words.get(i).getParsedForm().contains("P1pl")){// biz-cyan
			fill(0,240,255);
			stroke(0,240,255);
		}else if (words.get(i).getParsedForm().contains("A2pl")||words.get(i).getParsedForm().contains("P2pl")){// siz-mavi
			fill(0,0,255);
			stroke(0,0,255);
		}else if (words.get(i).getParsedForm().contains("A3pl")||words.get(i).getParsedForm().contains("P3pl")){// onlar-mor
			fill(255,0,255);
			stroke(255,0,255);
		}else if (words.get(i).getParsedForm().contains("A3sg")||words.get(i).getParsedForm().contains("P3sg")){// o-yeşil
			fill(0,240,0);
			stroke(0,240,0);
		}
		else{
			fill(0);
			stroke(0);
		}
	}	
}
		

