package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.WordDao;
import dao.WorkLineDao;
import dao.BookDao;


public class Bubble extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Bubble"});
	}
	
	int width = 800;
	int height = 600;
	
	float zoom = 1;
	boolean flag = false;
	int spaceCount=0;
	
	int id=6453;
	List<Word> words;
	List<WorkLine> worklines; //satırlar
	
	
	public void setup () {
		
		size (width, height);	
		stroke(255);     // Set line drawing color to white
		frameRate(50);  
		
		WorkLineDao workLineDao = new WorkLineDao();
		WordDao wordDao = new WordDao();
		
		try {	
			words = wordDao.getWordsWithParsedForm(id);
			worklines = workLineDao.getWorkLineOfAWork(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		if(flag)
			background(255);//circle 
		else
			background(180);
		scale(zoom);
		
		
		int x=(int) map(width,0,1920,0,30); //x coordinate of the ellipse
		int y=(int) map(height,0,1080,0,40); //y coordinate of the ellipse
		int r=(int) map(height,0,1080,0,15);
		int[] color = {50,50,50};
				
		int alpha=255;
		
		int interY = (int) map(height,0,1080,0,40);
				
		for(int i=0;i<words.size();i++){
			if(i!=0 && words.get(i).getWorkLineID() != words.get(i-1).getWorkLineID()){	
				y+=interY;
			}	
				
			x=(int)words.get(i).getWordStart()*3/2;	
			r=words.get(i).toString().length()*2;//length of the word
				
			if(flag)	
			alpha = 40;
						
			color = setColor(words.get(i).getText());	
			fill(color[0],color[1],color[2],alpha);
						
			ellipse(x,y,r,r);	
						
			//to see poetry
			if(flag){
				alpha = 255;
				textSize(11);
				fill(0,255);
				text(words.get(i).toString(),x,y);	
			}		
		}
	}
	
	public void keyPressed() {
		if(key == CODED){
			if(keyCode == UP){
				zoom += .03;
			}
			else if(keyCode == DOWN){
				zoom -= .03;	
			}
		}	
		if (key == ' '){
			spaceCount++;
			if(spaceCount%2 == 1){
				flag = true;
			}else 
				flag = false;
		}
	}	

	public int[] setColor(String word){
		int[] color = {50,50,50};
		
		if(word.contains("beyaz")){
			color[0] =255;
			color[1] =255;
			color[2] =255;
		}else if(word.contains("kızıl")){
			//fill(127,0,0);
			color[0] =127;
			color[1] =0;
			color[2] =0;
		
		}else if(word.contains("sarı")&&(!word.contains("sarık"))){
			//fill(255,255,20);
			color[0] =255;
			color[1] =255;
			color[2] =20;
			
		}else if(word.contains("siyah")||word.contains("kara")){
			//fill(255,255,20);
			color[0] =0;
			color[1] =0;
			color[2] =0;	
		}else if(word.contains("kırmızı")){
			color[0] =255;
			color[1] =0;
			color[2] =0;	
		}else if(word.contains("yeşil")){
			color[0] =0;
			color[1] =140;
			color[2] =0;	
		}else if(word.contains("mavi")){
			color[0] =0;
			color[1] =0;
			color[2] =200;	
		}else if(word.contains("mor")){
			color[0] =100;
			color[1] =0;
			color[2] =100;	
		}
		return color;
	}
}
