package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class Barcode extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Barcode"});
	}
	//id of a poem
	int id=6681;
	
	List<WorkLine> satırlar;
	List<Word> words;
	List<AffectiveResult> affectiveResults; 
	
	List<String> passiveVerbs = new ArrayList<String>();
	List<String> activeVerbs = new ArrayList<String>();
	List<String> benList = new ArrayList<String>();
	List<String> bizList = new ArrayList<String>();
	
	int defoult = 150;// defoult color for barcod

	public void setup () {
		size (displayWidth, displayHeight);		
		stroke(255); //Set line drawing color to white
		frameRate(50);  	
		

		WorkLineDao workLineDao = new WorkLineDao();
		WordDao wordDao = new WordDao();
		AffectiveDao affectiveDao = new AffectiveDao();
		
		try {		
			satırlar = workLineDao.getWorkLineOfAWork(id);
			words = wordDao.getWordsWithParsedForm(id);
			affectiveResults = affectiveDao.getResultsByWorkId(id);
			
			/*for(int i=0;i<affectiveResults.size();i++){
				System.out.println(affectiveResults.get(i).getText()+"  "+affectiveResults.get(i).getValence());
			}		
			/*for(int i=0;i<satırlar.size();i++){
				System.out.print(satırlar.get(i).getLine()+":	");
				for(int j=0;j<words.size();j++){
					if(satırlar.get(i).getLineID()==words.get(j).getWorkLineID()){
						System.out.print(words.get(j).getParsedForm()+" ");
					}
				}
				System.out.println();
			}*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		
		WordDao wordDao = new WordDao();
		
		int lengthOfPoem = satırlar.size();
		String nameOfPoem = satırlar.get(0).getLine();
		
		int rightAlignPos = displayWidth-100;
		int leftAlignPos = 100;
		int barcodeWidth = rightAlignPos-leftAlignPos;
	
		int y = 100;
		
		text("satır uzunlukları:",5,200);
		text("aktif-pasif fiil:",5,250);
		text("ben ve biz ayrımı:",5,330);
		text("valence:",5,420);
		text("arousal:",5,500);
		text("dominance:",5,580);

		
		stroke(100,100,240);
		strokeWeight(2);
		fill(240,50,50);
		text(nameOfPoem+":",100,100);
		
		//line(leftAlignPos,y,rightAlignPos,y);
		
		int iteration= barcodeWidth/lengthOfPoem;
		
		int satırLength;
		
		for(int i=0;i<lengthOfPoem;i++){
			
			//satır uzunluklarına göre:
			satırLength = (int) (satırlar.get(i).getLineFinish() - satırlar.get(i).getLineStart())/2 ;
			y=200;
			stroke(defoult);
			line(leftAlignPos+(iteration*(i+2)),y-satırLength,leftAlignPos+(iteration*(i+2)),y);
			
			//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- üsteünde mouse varsa interaction
			if(mouseX>leftAlignPos+(iteration*(i+2))-5&&mouseX<leftAlignPos+(iteration*(i+2))+5&& mouseY>y-satırLength&&mouseY<y){
				textSize(12);
				text(satırlar.get(i).getLine(),mouseX-20,mouseY-10);
			}
			//-*-*-*-*-*-*-*-*-*-*-*-*
		}	
		//active passive:
		for(int i=0;i<lengthOfPoem;i++){
			for(int j=0;j<words.size();j++){
				if(satırlar.get(i).getLineID()==words.get(j).getWorkLineID()){ // bulunduğumuz satırdaki sözcüklere göre satırı renklendir 
					if(activeVerb(j)){
						stroke(0,220,40);//yeşil
						activeVerbs.add(words.get(j).getText());
					}
					else if(passiveVerb(j)){
						stroke(220,0,0);//kırmızı
						passiveVerbs.add(words.get(j).getText());
					}
					else
						stroke(defoult);
				}
			}
			y=220;	
			
			line(leftAlignPos+(iteration*(i+2)),y,leftAlignPos+(iteration*(i+2)),y+60);
		}
		//ben ve biz ayrımı:
		for(int i=0;i<lengthOfPoem;i++){
			for(int j=0;j<words.size();j++){
				if(satırlar.get(i).getLineID()==words.get(j).getWorkLineID()){ // bulunduğumuz satırdaki sözcüklerin kişi çekimlerine göre renklendir
					if(ben(j)){
						benList.add(words.get(j).getText());
						stroke(0,220,40);//green
					}
					else if(biz(j)){
						bizList.add(words.get(j).getText());
						stroke(220,0,0);//red
					}
					else
						stroke(defoult);
				}
			}
			y=300;					
			line(leftAlignPos+(iteration*(i+2)),y,leftAlignPos+(iteration*(i+2)),y+60);
		}
		//valence-arousal-dominance
		for(int i=0;i<lengthOfPoem;i++){
			y=380;
			strokeValence(i);
			line(leftAlignPos+(iteration*(i+2)),y,leftAlignPos+(iteration*(i+2)),y+60);
			y=460;
			strokeArousal(i);
			line(leftAlignPos+(iteration*(i+2)),y,leftAlignPos+(iteration*(i+2)),y+60);
			y=540;
			strokeDominance(i);
			line(leftAlignPos+(iteration*(i+2)),y,leftAlignPos+(iteration*(i+2)),y+60);
		}	

		/*
		for(int i=0;i<activeVerbs.size();i++){
			System.out.println("act:"+activeVerbs.get(i));
		}
	
		for(int i=0;i<passiveVerbs.size();i++){
			System.out.println("pass:"+passiveVerbs.get(i));
		}
		for(int i=0;i<benList.size();i++){
			System.out.println("ben:"+benList.get(i));
		}
		for(int i=0;i<bizList.size();i++){
			System.out.println("biz:"+bizList.get(i));
		}*/
			
	}		
	public boolean passiveVerb(int j){
		if (words.get(j).getParsedForm().contains("Verb") && words.get(j).getParsedForm().contains("Pass")) return true;
		else return false;		
	}
	public boolean activeVerb(int j){
		if (words.get(j).getParsedForm().contains("Verb") && !(words.get(j).getParsedForm().contains("Pass"))) return true;
		else return false;	
	}
	public boolean ben(int j){
		if (words.get(j).getParsedForm().contains("A1sg")) return true;
		else return false;	
	}
	public boolean biz(int j){
		if (words.get(j).getParsedForm().contains("A1pl")) return true;
		else return false;	
	}
	public void strokeValence(int i){
		float valence = 3;
		if(i<affectiveResults.size())
			valence = Float.parseFloat(affectiveResults.get(i).getValence());
		//System.out.println("valence:" +valence);	
		//int color = (int) ((valence/5.0)*250);	
		
		if(valence<2.5){
			stroke(220,0,0);
		}else if(valence>3.5){
			stroke(0,220,0);
		}else
			stroke(defoult);	
	}
	public void strokeArousal(int i){
		float arousal=3;
		if(i<affectiveResults.size())
		arousal = Float.parseFloat(affectiveResults.get(i).getArousal());
		
		//int color = (int) ((arousal/5.0)*250);	
		if(arousal<2.5){
			stroke(220,0,0);
		}else if(arousal>3.5){
			stroke(0,220,0);
		}else
			stroke(defoult);
	}
	public void strokeDominance(int i){
		float dominance =3;
		if(i<affectiveResults.size())
		dominance = Float.parseFloat(affectiveResults.get(i).getDominance());
		
		//int color = (int) ((dominance/5.0)*250);	
		if(dominance<2.5){
			stroke(220,0,0);
		}else if(dominance>3.5){
			stroke(0,220,0);
		}else
			stroke(defoult);
	}
}
		

