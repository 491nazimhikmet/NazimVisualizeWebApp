package main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import model.AffectiveResult;
import model.Word;
import model.Work;
import model.WorkLine;
import model.Book;
import dao.AffectiveDao;
import dao.WordDao;
import dao.WorkDao;
import dao.WorkLineDao;
import dao.BookDao;


public class Barkod extends PApplet {
	
	public static void main (String[] args) {
		PApplet.main(new String[]{"--present", "main.Barkod"});
	}
	//id of a poem
	int id=6170;
	
	List<WorkLine> satırlar;
	List<Word> words;
	List<AffectiveResult> affectiveResults; 
	
	List<String> benList = new ArrayList<String>();
	List<String> bizList = new ArrayList<String>();
	
	int defoult = 150;//Default colour for bars
	
	int height = 600 ;
	int width = 1200;

	public void setup () {
		size (width, height);		
		frameRate(50); 
		
		stroke(255); //Set line drawing color to white

		WorkLineDao workLineDao = new WorkLineDao();
		WordDao wordDao = new WordDao();
		AffectiveDao affectiveDao = new AffectiveDao();
		
		try {		
			satırlar = workLineDao.getWorkLineOfAWork(id);
			words = wordDao.getWordsWithParsedForm(id);
			affectiveResults = affectiveDao.getResultsByWorkId(id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void draw(){
		background(255);
		
		WordDao wordDao = new WordDao();
		
		int lengthOfPoem = satırlar.size();
		String nameOfPoem = satırlar.get(0).getLine();
		
		int topMargin = (int) map(height,0,1080,0,200);
		float barcodeLength = (float) (height-topMargin*1.1);
		
		float interY = barcodeLength/lengthOfPoem;
		
		int textX = width/8;
		int textY = (int) map(height,0,1080,0,50);
		
		int shift = (int) map(height,0,1080,0,25);
		
		fill(0);
		text("Her bir çizgi şiirdeki bir satırı ifade eder.",textX,textY);
		text("Etken fiil içeren satırlar yeşil, edilgen fiil içeren satırlar kırmızı ile renklendirilmiştir.",textX,textY+shift);
		text("Satırda geçen fillerin çekimlerine göre sırasıyla: ben/kırmızı, sen/sarı, o/yeşil, biz/cyan, siz/mavi , onlar/mor ile renklendirilmiştir.",textX,textY+2*shift);
		text("Satırlar olumluluk/valence, uyarılma/arousal ve baskınlık/dominance değerlerine göre yüksek değerliler yeşil, düşük değerliler kırmızı ile renklendirilmiştir.",textX,textY+3*shift);

	
		int x = width/8;
		int y = topMargin;

		fill(0,0,200);
		stroke(0,0,200);
		
		text("satır uzunlukları:",x,y);
		text("etken-edilgen :",x*2,y);
		text("kişi çekimi :",x*3,y);
		text("olumluluk/valence:",x*4,y);
		text("uyarılma/arousal:",x*5,y);
		text("baskınlık/dominance:",x*6,y);
		
		strokeWeight(2);
		y = (int) (topMargin + 2*interY);
		
		int satırLength;
		int barWidth = width/12;  
		
		int mouseMargin = (int) map(height,0,1080,0,5);
		
		for(int i=0;i<lengthOfPoem;i++){
			
			satırLength = (int) (satırlar.get(i).getLineFinish() - satırlar.get(i).getLineStart())/2 ;
			stroke(defoult);
			
			line(x,y,x+satırLength,y);
			y += interY;
		
			//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- üsteünde mouse varsa interaction
			/*if(mouseX>x-mouseMargin && mouseX<x+satırLength+mouseMargin && mouseY>y-mouseMargin && mouseY<y+mouseMargin){
				text(satırlar.get(i).getLine(),width/3,topMargin+barcodeLength+interY);
			}
			//-*-*-*-*-*-*-*-*-*-*-*-*/
		}	
		
		y = (int) (topMargin + 2*interY);

		
		for(int i=0;i<lengthOfPoem;i++){ 	//etken edilgen:
			for(int j=0;j<words.size();j++){
				if(satırlar.get(i).getLineID()==words.get(j).getWorkLineID()){ // bulunduğumuz satırdaki sözcüklere göre satırı renklendir 
					if(etken(j)){
						stroke(0,220,40);//yeşil
					}
					else if(edilgen(j)){
						stroke(220,0,0);//kırmızı
					}
					else
						stroke(defoult);
				}
			}
			line(2*x,y,2*x+barWidth,y);	
			y += interY;
		}
		
		y = (int) (topMargin + 2*interY);

		
		for(int i=0;i<lengthOfPoem;i++){	//ben ve biz ayrımı:
			for(int j=0;j<words.size();j++){
				if(satırlar.get(i).getLineID() == words.get(j).getWorkLineID()){
					strokeSubject(j);
				}
			}
			line(3*x,y,3*x+barWidth,y);	
			y += interY;
		}
		
		y = (int) (topMargin + 2*interY);

		
		for(int i=0;i<lengthOfPoem;i++){ //valence-arousal-dominance
	
			strokeValence(i);
			line(4*x,y,4*x+barWidth,y);
			strokeArousal(i);
			line(5*x,y,5*x+barWidth,y);
			strokeDominance(i);
			line(6*x,y,6*x+barWidth,y);
			
			y += interY;
		}
	}		
	public boolean edilgen(int j){
		if (words.get(j).getParsedForm().contains("Verb") && words.get(j).getParsedForm().contains("Pass")) return true;
		else return false;		
	}
	public boolean etken(int j){
		if (words.get(j).getParsedForm().contains("Verb") && !(words.get(j).getParsedForm().contains("Pass"))) return true;
		else return false;	
	}
	
	public void strokeValence(int i){
		float valence = 3;
		if(i<affectiveResults.size())
			valence = Float.parseFloat(affectiveResults.get(i).getValence());
		//System.out.println("valence:" +valence);	
		//int c = (int) ((valence/5.0)*255);	
		
		//stroke(c,255,255-c);
		
		if(valence<2.5){
			stroke(220,0,0);//red
		}else if(valence>3.5){
			stroke(0,220,0);//green
		}else
			stroke(defoult);
	}
	public void strokeArousal(int i){
		float arousal=3;
		if(i<affectiveResults.size())
		arousal = Float.parseFloat(affectiveResults.get(i).getArousal());
		
		//int color = (int) ((arousal/5.0)*250);	
		if(arousal<2.5){
			stroke(220,0,0);
		}else if(arousal>3.5){
			stroke(0,220,0);
		}else
			stroke(defoult);
	}
	public void strokeDominance(int i){
		float dominance =3;
		if(i<affectiveResults.size())
		dominance = Float.parseFloat(affectiveResults.get(i).getDominance());
		
		//int color = (int) ((dominance/5.0)*250);	
		if(dominance<2.5){
			stroke(220,0,0);
		}else if(dominance>3.5){
			stroke(0,220,0);
		}else
			stroke(defoult);
	}
	public void strokeSubject(int i){
		if (words.get(i).getParsedForm().contains("A1sg")||words.get(i).getParsedForm().contains("P1sg")){// ben-kırmızı
			fill(255,0,0);
			stroke(255,0,0);			
		}else if (words.get(i).getParsedForm().contains("A2sg")||words.get(i).getParsedForm().contains("P2sg")){// sen-sarı
			fill(255,220,0);
			stroke(255,220,0);
		}else if (words.get(i).getParsedForm().contains("A1pl")||words.get(i).getParsedForm().contains("P1pl")){// biz-cyan
			fill(0,240,255);
			stroke(0,240,255);
		}else if (words.get(i).getParsedForm().contains("A2pl")||words.get(i).getParsedForm().contains("P2pl")){// siz-mavi
			fill(0,0,255);
			stroke(0,0,255);
		}else if (words.get(i).getParsedForm().contains("A3pl")||words.get(i).getParsedForm().contains("P3pl")){// onlar-mor
			fill(255,0,255);
			stroke(255,0,255);
		}else if (words.get(i).getParsedForm().contains("A3sg")||words.get(i).getParsedForm().contains("P3sg")){// o-yeşil
			fill(0,240,0);
			stroke(0,240,0);
		}
		else{
			fill(defoult);
			stroke(defoult);
		}
	}	
}
		

