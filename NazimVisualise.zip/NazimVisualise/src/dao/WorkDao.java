package dao;

import java.sql.SQLException;
import java.util.List;

import model.Work;
import model.WorkLine;

public class WorkDao extends DBConnection{
	
	public Work getWorkByID(int workID) throws SQLException{
		startConnection();
		String query = "SELECT * FROM WORK WHERE workId = "+Integer.toString(workID);
		
		Work work = Extractors.extractWork(this.getStmt().executeQuery(query)).get(0);
		
		WorkLineDao workLineDao = new WorkLineDao();
		List<WorkLine> workLines = workLineDao.getWorkLineOfAWork(workID);
		work.setWorkLines(workLines);
		closeConnection();
		return work;
	}
	
	public List<Work> getWorksOfABook(int bookID) throws SQLException{
		startConnection();
		String query = "SELECT * FROM Work WHERE bookId = "+Integer.toString(bookID);
		 List<Work> returnlist = Extractors.extractWork(this.getStmt().executeQuery(query));
		 closeConnection();
		 return returnlist;
	}
	
	public List<Work> getLocationsofWorks() throws SQLException{
		startConnection();
		String query ="SELECT * FROM `work` WHERE `LocationOfComp` !=''"+"";
		List<Work> returnlist = Extractors.extractWork(this.getStmt().executeQuery(query));
		closeConnection();
		return returnlist;
	}
}

