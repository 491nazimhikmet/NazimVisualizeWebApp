package dao;

import java.sql.SQLException;
import java.util.List;

import model.AffectiveResult;


public class AffectiveDao extends DBConnection {
	public List<AffectiveResult> getResultsByWorkId(int workID) throws SQLException{
		startConnection();
		String query="SELECT * FROM `affectiveresults` WHERE `type` = 1 and textId in(select lineId from workLine where workId ="+Integer.toString(workID)+" )order by textId";

		List<AffectiveResult> returnlist = Extractors.extractAffectiveResults(this.getStmt().executeQuery(query));
		closeConnection();
		
		return returnlist; 
	}
}
