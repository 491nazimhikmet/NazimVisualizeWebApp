package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.AffectiveResult;
import model.Work;
import model.WorkLine;
import model.Book;
import model.Word;

public class Extractors {
	
	public Extractors(){}
	
	public static List<WorkLine> extractWorkLine(ResultSet rs) throws SQLException{
		List<WorkLine> result = new ArrayList<WorkLine>();
	
		while(rs.next()){
			WorkLine workLine = new WorkLine();
			workLine.setLineID(rs.getInt("lineId"));
			workLine.setLine(rs.getString("line"));
			workLine.setLineStart(rs.getDouble("lineStart"));
			workLine.setLineFinish(rs.getDouble("lineFinish"));
			workLine.setWorkID(rs.getInt("workId"));
			
			result.add(workLine);
		}
		
		return result;
	}
	
	public static List<Work> extractWork(ResultSet rs) throws SQLException{
		List<Work> result = new ArrayList<Work>();
		
		while(rs.next()){
			Work work = new Work();
			work.setBookID(rs.getInt("BookId"));
			work.setName(rs.getString("Name"));
			work.setLocationOfComp(rs.getString("LocationOfComp"));
			work.setYear(rs.getString("Year"));
			work.setWorkID(rs.getInt("WorkId"));
			work.setPageNum(rs.getInt("pageNum"));
			work.setTitle(rs.getString("Title"));
			
			result.add(work);
		}
		
		return result;
	}
	public static List<Word> extractWord(ResultSet rs) throws SQLException{
		List<Word> result = new ArrayList<Word>();
		
		while(rs.next()){
			Word word = new Word();
			word.setBold(rs.getBoolean("isBold"));
			word.setFont(rs.getString("font"));
			word.setItalic(rs.getBoolean("isItalic"));
			word.setText(rs.getString("text"));
			word.setWordFinish(rs.getDouble("wordFinish"));
			word.setWordID(rs.getInt("wordId"));
			word.setWordStart(rs.getDouble("wordStart"));
			word.setWorkLineID(rs.getInt("workLineId"));
			word.setDisambiguated(rs.getString("disambiguated"));
				
			result.add(word);
		}
		
		return result;
	}
	public static List<Word> extractWordsWithParsedForm(ResultSet rs) throws SQLException{
		List<Word> result = new ArrayList<Word>();
		
		while(rs.next()){
			Word word = new Word();
			word.setBold(rs.getBoolean("isBold"));
			word.setFont(rs.getString("font"));
			word.setItalic(rs.getBoolean("isItalic"));
			word.setText(rs.getString("text"));
			word.setWordFinish(rs.getDouble("wordFinish"));
			word.setWordID(rs.getInt("wordId"));
			word.setWordStart(rs.getDouble("wordStart"));
			word.setWorkLineID(rs.getInt("workLineId"));
			word.setParsedForm(rs.getString("parsedForm"));
			word.setDisambiguated(rs.getString("disambiguated"));
				
			result.add(word);
		}
		
		return result;
	}
	
	public static List<Book> extractBook(ResultSet rs) throws SQLException{
		List<Book> result = new ArrayList<Book>();
		
		while(rs.next()){
			Book book = new Book();
			book.setBookID(rs.getInt("bookId"));
			book.setName(rs.getString("Name"));
			book.setLocation(rs.getString("Location"));
			book.setType(rs.getInt("type"));
			book.setYear(rs.getString("Year"));
			
			result.add(book);
		}
		
		return result;
	}
	public static List<Book> extractBookWithCnt(ResultSet rs) throws SQLException{
		List<Book> result = new ArrayList<Book>();
		
		while(rs.next()){
			Book book = new Book();
			book.setBookID(rs.getInt("bookId"));
			book.setName(rs.getString("Name"));
			book.setLocation(rs.getString("Location"));
			book.setType(rs.getInt("type"));
			book.setYear(rs.getString("Year"));
			book.setWordCnt(rs.getInt("cnt"));
			
			result.add(book);
		}
		
		return result;
	}
	public static List<AffectiveResult> extractAffectiveResults(ResultSet rs) throws SQLException{
		
		List<AffectiveResult> result = new ArrayList<AffectiveResult>();
		
		while(rs.next()){
			AffectiveResult affRes = new AffectiveResult();
			
			affRes.setId(rs.getInt("textId"));
			affRes.setType(rs.getInt("type"));
			affRes.setText(rs.getString("text"));
			affRes.setArousal(rs.getString("arousal"));
			affRes.setDominance(rs.getString("dominance"));
			affRes.setValence(rs.getString("valence"));
			
			result.add(affRes);
		}
		
		return result;
	}
	public static String extractParsedForm(ResultSet rs) throws SQLException{
		String result="";
		if(rs.next())
			 result = rs.getString("parsedForm") ;
		
		return result;
	}
}
