package dao;

import java.sql.SQLException;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import dao.DBConnection;
import model.Book;
import model.Word;
import model.Work;


public class WordDao extends DBConnection{

	public List<Word> getWordsOfAWorkline(int lineID) throws SQLException{
		startConnection();
		String query = "SELECT * FROM Word WHERE workLineId = "+Integer.toString(lineID);
		List<Word> returnlist = Extractors.extractWord(this.getStmt().executeQuery(query));
		 closeConnection();
		 return returnlist; 
	}
	public List<Word> getWordsOfAWork(int workID) throws SQLException{
		startConnection();
		String query = "SELECT * FROM word WHERE workLineId IN (SELECT lineId from workline WHERE WorkId ="+Integer.toString(workID)+")";
		//dbde workID de tutalım
		List<Word> returnlist = Extractors.extractWord(this.getStmt().executeQuery(query));
		 closeConnection();
		 return returnlist; 
	}
	
	public List<Word> getWordsWithParsedForm(int workID) throws SQLException{
		startConnection();
		String query = "SELECT w.*,wp.parsedForm FROM word w,wordParseForms wp WHERE w.wordId = wp.wordId and wp.probOrder = 1 and workLineId IN (SELECT lineId from workline WHERE WorkId ="+Integer.toString(workID)+")";
		//dbde workID de tutalım
		List<Word> returnlist = Extractors.extractWordsWithParsedForm(this.getStmt().executeQuery(query));
		 closeConnection();
		 return returnlist; 
	}
	
	public List<Book> getBookCounterOfWord(String stem) throws SQLException{
		startConnection();
		
		String query = "select b.*,o.cnt from book b, (select w.bookId, sum(t.cnt) as cnt from work w,(select workId,sum(k.wrdCnt) as cnt from workLine a ,(SELECT workLineId,count(*) as wrdCnt FROM `word` WHERE lower(disambiguated) like lower('"+stem+"')group by workLineId) k where a.lineId = k.workLineId group by workId) t where t.workId = w.workId group by w.bookId) o where b.bookId = o.bookId";
		
		List<Book> returnlist = Extractors.extractBookWithCnt(this.getStmt().executeQuery(query));
		closeConnection();
		
		return returnlist; 
	}
	public List<Word> addParsedForm(List<Word> wordList)throws SQLException{
		int currentID;
		String currentParsedForm;
		startConnection();
		for(int i=0;i<wordList.size();i++){
			currentID = wordList.get(i).getWordID();
			String query ="SELECT * FROM `wordParseForms` WHERE `wordId` ="+Integer.toString(currentID)+" AND `probOrder` =1";
			currentParsedForm = Extractors.extractParsedForm(this.getStmt().executeQuery(query));
			wordList.get(i).setParsedForm(currentParsedForm);
		}	
		closeConnection();
		return wordList;
	}
}

