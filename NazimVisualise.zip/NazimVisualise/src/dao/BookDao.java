package dao;

import java.sql.SQLException;
import java.util.List;

import model.Book;
import model.Work;


public class BookDao extends DBConnection{
	public Book getBookByID(int bookID) throws SQLException{
		startConnection();
		String query = "SELECT * FROM BOOK WHERE bookId = "+Integer.toString(bookID);
		
		Book book = Extractors.extractBook(getStmt().executeQuery(query)).get(0);
		closeConnection();
		return book;
	}
	public List<Book> getBooks() throws SQLException{
		startConnection();
		String query = "SELECT * FROM BOOK ";
		
		List<Book> books = Extractors.extractBook(getStmt().executeQuery(query));
		closeConnection();
		return books;
	}
}
