package model;

public class Location {
	private String name;
	private int frequncy;
	private double  xcoordinate;
	private double  ycoordinate;

	
	public Location(String name){
		this.name=name;
		this.frequncy=0;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFrequncy() {
		return frequncy;
	}
	public void setFrequncy(int frequncy) {
		this.frequncy = frequncy;
	}

	public double getXcoordinate() {
		return xcoordinate;
	}

	public void setXcoordinate(double xcoordinate) {
		this.xcoordinate = xcoordinate;
	}

	public double getYcoordinate() {
		return ycoordinate;
	}

	public void setYcoordinate(double ycoordinate) {
		this.ycoordinate = ycoordinate;
	}
	
}
